package com.example.week5assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
